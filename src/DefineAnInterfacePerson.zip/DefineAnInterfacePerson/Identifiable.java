package DefineAnInterfacePerson;

public interface Identifiable  {
    String getId();

}

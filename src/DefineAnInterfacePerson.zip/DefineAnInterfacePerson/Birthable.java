package DefineAnInterfacePerson;

public interface Birthable {
    String getBirthDate();
}
